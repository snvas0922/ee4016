# Pretrained weights
Download pretrained weights there: 
https://drive.google.com/drive/folders/16PlVKhTNkSyWFx52RPb2hXPIQveNGbxS

